Compile & Run Instructions:
- 
To compile this project use "make"
and to clean (remove) compiled files use "make clean"
***************************
Resources Used:
- 
1. https://www.cse.unsw.edu.au/~cs1521/19T2/notes/G/notes.html
2. https://medium.com/@sohamshah456/producer-consumer-programming-with-c-d0d47b8f103f
3. https://makefiletutorial.com/

(as well as class slides from Canvas)

By Alexia Perez, UIN: 127008512
