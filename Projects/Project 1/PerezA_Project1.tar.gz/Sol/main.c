// C file for main function for producer-consumer solution
// By Alexia Perez | 127008512

#include "functions.h"
/* FUNCTION DECLARATIONS */
int addMsg(pthread_t self) // creates message to add to queue & prints info to terminal
{
    int i = 0;
    int msg = 1 + rand()%100; // generates a random integer as the msg (max = 100)
    while(!pthread_equal(*(producers+i),self) && i < totalProd){
        i++;
    }
    printf("Producer %d produced msg: %d \n",i+1,msg);
    return msg;
}

void recvMsg(int msg,pthread_t self) // prints info about message read to the terminal
{
    int i = 0;
    while(!pthread_equal(*(consumers+i),self) && i < totalCons){
        i++;
    }
    printf("\nConsumer %d received message: %d \n",i+1,msg); // ack for the received message
}

void* producer(void *args) // code for producer threads
{
    int currProd = 0; // current producer "ID"
    while(currProd < queueLen)
    {
        int m = addMsg(pthread_self()); // creates a msg
        sem_wait(&empty); // lock the "empty" semaphore
        sem_wait(&mutex); // lock the "mutex" semaphore
        ++indx;			   // update the queue's index to add things to
        *(msgQueue + indx) = m; // adds msg to queue
        prodTracker[currProd] = prodTracker[currProd] + 1; // updates # of msg produces for this producer ID
        currProd = currProd + 1; // updates the current producer
        sem_post(&mutex); // unlock mutex
        sem_post(&full); // unlock full
        sleep(1+rand()%2); // thread sleeps for some random amount of seconds between 1 or 3
    }
    return NULL;
}

void* consumer(void *args) // code for consumer threads
{
    int recv;
    int currCons = 0; //  current consumer "ID"
    while(currCons < queueLen)
    {
        sem_wait(&full); // lock the "full" semaphore
        sem_wait(&mutex); // lock the "mutex" semaphore
        recv = *(msgQueue+indx); // take a msg from the queue
        recvMsg(recv,pthread_self()); // print updates about the newly received message
        --indx; // update the queue's index to add things to
        consTracker[currCons] = consTracker[currCons] + 1; // to check total consumed msg by this consumer
        currCons= currCons+ 1; // update the current consumer
        sem_post(&mutex); // unlock mutex
        sem_post(&empty); // unlock empty
        sleep(1+rand()%2); // thread sleeps for some random amount of seconds between 1 or 3
    }
    return NULL;
}

/* MAIN FUNCTION CODE */
int main(void){

    int i,status;
    srand(time(NULL));
    sem_init(&mutex,0,1);
    sem_init(&full,0,0);

    // User inputs
    printf("Please enter number of Producers:");
    scanf("%d",&totalProd);
    producers = (pthread_t*) malloc(totalProd*sizeof(pthread_t));
    printf("Please enter number of Consumers:");
    scanf("%d",&totalCons);
    consumers = (pthread_t*) malloc(totalCons*sizeof(pthread_t));
    printf("Please enter maximum msg queue capacity:");
    scanf("%d",&queueLen);

    // Implementation code
    msgQueue = (int*) malloc(queueLen*sizeof(int)); // the message queue
    prodTracker = (int *) malloc(totalProd*queueLen); // keeps track of # of messages produced per producer
    consTracker = (int *) malloc(totalCons*queueLen); // keeps track of # of messages consumed per consumer

    sem_init(&empty,0,queueLen); // initialize semaphores for synchronization

    for(i=0;i<totalProd;i++) // create the producer threads
    {
        status = pthread_create(producers+i,NULL,producer, NULL);
        if(status != 0)
        {
            printf("Error creating producer %d: %s\n", i + 1, strerror(status));
        }
    }
    for(i=0;i<totalCons;i++) // create the consumer threads
    {
        status = pthread_create(consumers+i,NULL,consumer, NULL);
        if(status != 0)
        {
            printf("Error creating consumer %d: %s\n", i + 1, strerror(status));
        }
    }

    for(i=0;i<totalProd;i++) // make sure all producer threads finish
    {
        pthread_join(*(producers+i),NULL);
    }
    for(i=0;i<totalCons;i++) // make sure all consumer threads finish
    {
        pthread_join(*(consumers+i),NULL);
    }

    // Code below helps check if some producers/consumers were treated unfairly during execution
    printf("Producers 1-%d produced the following amount of messages, respectively:\n", totalProd);
    for(int i = 0; i < totalProd; i++)
    {
        printf("%d ", prodTracker[i]);
    }
    printf("Consumers 1-%d consumed the following amount of messages, respectively:\n", totalCons);
    for(int i = 0; i < totalProd; i++)
    {
        printf("%d ", consTracker[i]);
    }
    printf("\n");
    return 0;
}