// Header file for functions used in producer-consumer solution
// By Alexia Perez | 127008512

#ifndef CSCE410_PROJ1_FUNCTIONS_H
#define CSCE410_PROJ1_FUNCTIONS_H

/* IMPORTS */
#include "functions.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

/* GLOBAL VARIABLES */
pthread_t *producers;
pthread_t *consumers;
sem_t mutex,empty,full;
int *msgQueue, *prodTracker, *consTracker;
int indx=-1, totalProd, totalCons, queueLen;

/* FUNCTION DECLARATIONS */
int addMsg(pthread_t self);
void recvMsg(int p,pthread_t self);
void* producer(void *args);
void* consumer(void *args);

#endif //CSCE410_PROJ1_FUNCTIONS_H
